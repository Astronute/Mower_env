/* SPDX-License-Identifier: MPL-2.0 */

#ifndef __ZMQ_OBJECT_HPP_INCLUDED__
#define __ZMQ_OBJECT_HPP_INCLUDED__

#include <string>

#include "endpoint.hpp"
#include "macros.hpp"
#include "stdint.hpp"

namespace zmq
{
struct i_engine;
struct endpoint_t;
struct pending_connection_t;
struct command_t;
class ctx_t;
class pipe_t;
class socket_base_t;
class session_base_t;
class io_thread_t;
class own_t;

//  Base class for all objects that participate in inter-thread
//  communication.

class object_t
{
  public:
    object_t (zmq::ctx_t *ctx_, uint32_t tid_);
    object_t (object_t *parent_);
    virtual ~object_t ();

    uint32_t get_tid () const;
    void set_tid (uint32_t id_);
    ctx_t *get_ctx () const;
    void process_command (const zmq::command_t &cmd_);
    void send_inproc_connected (zmq::socket_base_t *socket_);
    void send_bind (zmq::own_t *destination_,
                    zmq::pipe_t *pipe_,
                    bool inc_seqnum_ = true);

  protected:
    //  Using following function, socket is able to access global
    //  repository of inproc endpoints.
    int register_endpoint (const char *addr_, const zmq::endpoint_t &endpoint_);
    int unregister_endpoint (const std::string &addr_, socket_base_t *socket_);
    void unregister_endpoints (zmq::socket_base_t *socket_);
    zmq::endpoint_t find_endpoint (const char *addr_) const;
    void pend_connection (const std::string &addr_,
                          const endpoint_t &endpoint_,
                          pipe_t **pipes_);
    void connect_pending (const char *addr_, zmq::socket_base_t *bind_socket_);

    void destroy_socket (zmq::socket_base_t *socket_);

    //  Logs an message.
    void log (const char *format_, ...);

    //  Chooses least loaded I/O thread.
    zmq::io_thread_t *choose_io_thread (uint64_t affinity_) const;

    //  Derived object can use these functions to send commands
    //  to other objects.
    void send_stop ();
    void send_plug (zmq::own_t *destination_, bool inc_seqnum_ = true);
    void send_own (zmq::own_t *destination_, zmq::own_t *object_);
    void send_attach (zmq::session_base_t *destination_,
                      zmq::i_engine *engine_,
                      bool inc_seqnum_ = true);
    void send_activate_read (zmq::pipe_t *destination_);
    void send_activate_write (zmq::pipe_t *destination_, uint64_t msgs_read_);
    void send_hiccup (zmq::pipe_t *destination_, void *pipe_);
    void send_pipe_peer_stats (zmq::pipe_t *destination_,
                               uint64_t queue_count_,
                               zmq::own_t *socket_base,
                               endpoint_uri_pair_t *endpoint_pair_);
    void send_pipe_stats_publish (zmq::own_t *destination_,
                                  uint64_t outbound_queue_count_,
                                  uint64_t inbound_queue_count_,
                                  endpoint_uri_pair_t *endpoint_pair_);
    void send_pipe_term (zmq::pipe_t *destination_);
    void send_pipe_term_ack (zmq::pipe_t *destination_);
    void send_pipe_hwm (zmq::pipe_t *destination_, int inhwm_, int outhwm_);
    void send_term_req (zmq::own_t *destination_, zmq::own_t *object_);
    void send_term (zmq::own_t *destination_, int linger_);
    void send_term_ack (zmq::own_t *destination_);
    void send_term_endpoint (own_t *destination_, std::string *endpoint_);
    void send_reap (zmq::socket_base_t *socket_);
    void send_reaped ();
    void send_done ();
    void send_conn_failed (zmq::session_base_t *destination_);


    //  These handlers can be overridden by the derived objects. They are
    //  called when command arrives from another thread.
    virtual void process_stop ();
    virtual void process_plug ();
    virtual void process_own (zmq::own_t *object_);
    virtual void process_attach (zmq::i_engine *engine_);
    virtual void process_bind (zmq::pipe_t *pipe_);
    virtual void process_activate_read ();
    virtual void process_activate_write (uint64_t msgs_read_);
    virtual void process_hiccup (void *pipe_);
    virtual void process_pipe_peer_stats (uint64_t queue_count_,
                                          zmq::own_t *socket_base_,
                                          endpoint_uri_pair_t *endpoint_pair_);
    virtual void
    process_pipe_stats_publish (uint64_t outbound_queue_count_,
                                uint64_t inbound_queue_count_,
                                endpoint_uri_pair_t *endpoint_pair_);
    virtual void process_pipe_term ();
    virtual void process_pipe_term_ack ();
    virtual void process_pipe_hwm (int inhwm_, int outhwm_);
    virtual void process_term_req (zmq::own_t *object_);
    virtual void process_term (int linger_);
    virtual void process_term_ack ();
    virtual void process_term_endpoint (std::string *endpoint_);
    virtual void process_reap (zmq::socket_base_t *socket_);
    virtual void process_reaped ();
    virtual void process_conn_failed ();


    //  Special handler called after a command that requires a seqnum
    //  was processed. The implementation should catch up with its counter
    //  of processed commands here.
    virtual void process_seqnum ();

  private:
    //  Context provides access to the global state.
    zmq::ctx_t *const _ctx;

    //  Thread ID of the thread the object belongs to.
    uint32_t _tid;

    void send_command (const command_t &cmd_);

    ZMQ_NON_COPYABLE_NOR_MOVABLE (object_t)
};
}

#endif
